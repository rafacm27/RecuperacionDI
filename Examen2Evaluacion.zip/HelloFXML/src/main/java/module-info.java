module com.example.hellofxml {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.hellofxml to javafx.fxml;
    exports com.example.hellofxml;
}