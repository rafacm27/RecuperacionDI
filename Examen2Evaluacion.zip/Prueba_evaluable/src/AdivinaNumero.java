import java.util.Scanner;
import java.util.Random;

public class AdivinaNumero {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        int numeroAdivinar = random.nextInt(100) + 1; // Genera un número aleatorio entre 1 y 100
        int intentosMaximos = 10;

        System.out.println("¡Bienvenido al juego de adivinar el número!");
        System.out.println("Tienes que adivinar un número entre 1 y 100.");
        System.out.println("Tienes " + intentosMaximos + " oportunidades.");

        for (int intento = 1; intento <= intentosMaximos; intento++) {
            System.out.print("Intento " + intento + ": Ingresa tu número: ");
            int numeroUsuario = scanner.nextInt();

            if (numeroUsuario == numeroAdivinar) {
                System.out.println("¡Felicidades! Has adivinado el número correctamente.");
                break;
            } else if (numeroUsuario < numeroAdivinar) {
                System.out.println("El número es mayor. Intenta de nuevo.");
            } else {
                System.out.println("El número es menor. Intenta de nuevo.");
            }

            if (intento == intentosMaximos) {
                System.out.println("Lo siento, has agotado tus oportunidades. El número correcto era: " + numeroAdivinar);
            }
        }

        scanner.close();
    }
}
