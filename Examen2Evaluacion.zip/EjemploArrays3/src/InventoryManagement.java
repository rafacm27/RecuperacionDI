// Ejemplo práctico: Gestión de inventario con arrays
public class InventoryManagement {
    public static void main(String[] args) {
        // 1. Crear e inicializar dos arrays paralelos: nombres de productos y sus precios
        String[] productos = {"Manzanas", "Naranjas", "Plátanos", "Uvas", "Peras"};
        double[] precios = {1.2, 0.8, 1.1, 2.5, 1.7};

        // 2. Mostrar el inventario completo
        System.out.println("Inventario actual:");
        for (int i = 0; i < productos.length; i++) {
            System.out.println(productos[i] + " - $" + precios[i]);
        }

        // 3. Calcular y mostrar el producto más caro y más barato
        double precioMax = precios[0];
        double precioMin = precios[0];
        String productoMax = productos[0];
        String productoMin = productos[0];
        for (int i = 1; i < precios.length; i++) {
            if (precios[i] > precioMax) {
                precioMax = precios[i];
                productoMax = productos[i];
            }
            if (precios[i] < precioMin) {
                precioMin = precios[i];
                productoMin = productos[i];
            }
        }

        System.out.println("\nProducto más caro: " + productoMax + " - $" + precioMax);
        System.out.println("Producto más barato: " + productoMin + " - $" + precioMin);

        // 4. Calcular el costo total del inventario
        double costoTotal = 0;
        for (double precio : precios) {
            costoTotal += precio;
        }
        System.out.println("\nCosto total del inventario: $" + costoTotal);

        // 5. Buscar un producto en el inventario por nombre
        String buscar = "Plátanos";
        boolean encontrado = false;
        for (int i = 0; i < productos.length; i++) {
            if (productos[i].equalsIgnoreCase(buscar)) {
                System.out.println("\nProducto encontrado: " + productos[i] + " - $" + precios[i]);
                encontrado = true;
                break;
            }
        }
        if (!encontrado) {
            System.out.println("\nEl producto \"" + buscar + "\" no está en el inventario.");
        }
    }
}
