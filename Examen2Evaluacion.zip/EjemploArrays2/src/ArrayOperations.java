// Ejemplo práctico de manejo de arrays: operaciones básicas
public class ArrayOperations {
    public static void main(String[] args) {
        // 1. Crear e inicializar un array de notas de estudiantes
        double[] notas = {8.5, 7.0, 9.2, 6.8, 10.0, 5.4};

        // 2. Calcular el promedio de las notas
        double suma = 0;
        for (double nota : notas) {
            suma += nota;
        }
        double promedio = suma / notas.length;

        // 3. Determinar la nota más alta y más baja
        double maxNota = notas[0];
        double minNota = notas[0];
        for (double nota : notas) {
            if (nota > maxNota) maxNota = nota;
            if (nota < minNota) minNota = nota;
        }

        // 4. Contar cuántos estudiantes aprobaron (nota >= 6.0)
        int aprobados = 0;
        for (double nota : notas) {
            if (nota >= 6.0) aprobados++;
        }

        // 5. Mostrar los resultados
        System.out.println("Notas de los estudiantes:");
        for (double nota : notas) {
            System.out.println(nota);
        }
        System.out.println("\nPromedio de notas: " + promedio);
        System.out.println("Nota más alta: " + maxNota);
        System.out.println("Nota más baja: " + minNota);
        System.out.println("Número de estudiantes aprobados: " + aprobados);
    }
}
