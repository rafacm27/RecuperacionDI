import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Declaración de una variable de tipo char
        char letra = 'A'; // Representa el carácter 'A'

        // Imprimir el valor de la variable
        System.out.println("El valor de la letra es: " + letra);

        // Comparar el carácter con otro usando operadores relacionales
        if (letra == 'A') {
            System.out.println("La letra es A.");
        } else {
            System.out.println("La letra no es A.");
        }

        // Operaciones con valores char (valores Unicode)
        char siguienteLetra = (char) (letra + 1); // 'A' es 65 en Unicode, sumamos 1 para obtener 'B'
        System.out.println("La siguiente letra es: " + siguienteLetra);

        // Uso de caracteres especiales
        char simbolo = '@';
        System.out.println("Un símbolo especial: " + simbolo);

        // Caracteres de escape
        char nuevaLinea = '\n'; // Representa un salto de línea
        char comillaSimple = '\''; // Representa una comilla simple
        System.out.println("Ejemplo de caracteres de escape:");
        System.out.println("Nueva línea:" + nuevaLinea + "Con comilla simple: " + comillaSimple);
    }
}
