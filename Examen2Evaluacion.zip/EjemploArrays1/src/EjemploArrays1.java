// Ejemplo práctico de uso de arrays en Java
public class EjemploArrays1 {
    public static void main(String[] args) {
        // 1. Declaración y creación de un array de enteros
        int[] numeros = new int[5]; // Crea un array con espacio para 5 elementos

        // 2. Inicialización del array con valores
        numeros[0] = 10;
        numeros[1] = 20;
        numeros[2] = 30;
        numeros[3] = 40;
        numeros[4] = 50;

        // 3. Mostrar los valores del array usando un bucle for
        System.out.println("Elementos del array:");
        for (int i = 0; i < numeros.length; i++) {
            System.out.println("Elemento en índice " + i + ": " + numeros[i]);
        }

        // 4. Uso de un bucle for-each para recorrer el array
        System.out.println("\nRecorriendo el array con for-each:");
        for (int numero : numeros) {
            System.out.println("Valor: " + numero);
        }

        // 5. Crear y llenar un array de cadenas (String) en una sola línea
        String[] nombres = {"Ana", "Luis", "Carlos", "María"};

        // 6. Mostrar los valores del array de cadenas
        System.out.println("\nNombres en el array:");
        for (String nombre : nombres) {
            System.out.println(nombre);
        }

        // 7. Ejemplo de suma de elementos en un array de enteros
        int suma = 0;
        for (int numero : numeros) {
            suma += numero; // Sumar cada elemento al acumulador
        }
        System.out.println("\nSuma de los elementos del array de enteros: " + suma);

        // 8. Buscar un elemento en el array
        int buscar = 30;
        boolean encontrado = false;
        for (int numero : numeros) {
            if (numero == buscar) {
                encontrado = true;
                break; // Terminar el bucle si se encuentra el número
            }
        }
        if (encontrado) {
            System.out.println("\nEl número " + buscar + " fue encontrado en el array.");
        } else {
            System.out.println("\nEl número " + buscar + " no está en el array.");
        }
    }
}
