package Ej1;

public class DemasiadosIntentosException extends Exception {
    public DemasiadosIntentosException(String mensaje) {
        super(mensaje);
    }
}

