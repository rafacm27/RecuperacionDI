package Ej1;

public class CredencialesIncorrectasException extends Exception {
    public CredencialesIncorrectasException(String mensaje) {
        super(mensaje);
    }
}
