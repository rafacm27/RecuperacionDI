package Ej1;

public class CuentaBloqueadaException extends Exception {
    public CuentaBloqueadaException(String mensaje) {
        super(mensaje);
    }
}
