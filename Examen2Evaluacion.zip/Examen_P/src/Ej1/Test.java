package Ej1;

import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        SistemaSeguridad seguridad = new SistemaSeguridad();

        while (true) {
            System.out.print("Ingrese la contraseña: ");
            String clave = scanner.nextLine();

            try {
                seguridad.acceder(clave);
                break;
            } catch (CuentaBloqueadaException e) {
                System.out.println("⚠ " + e.getMessage());
            } catch (CredencialesIncorrectasException | DemasiadosIntentosException e) {
                System.out.println("❌ " + e.getMessage());
            }
        }

        seguridad.mostrarHistorial();
        scanner.close();
    }
}
