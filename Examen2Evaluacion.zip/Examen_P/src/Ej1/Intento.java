package Ej1;

public class Intento {
    private long timestamp;
    private String resultado;

    public Intento(String resultado) {
        this.timestamp = System.currentTimeMillis();
        this.resultado = resultado;
    }

    @Override
    public String toString() {
        return "Intento en " + timestamp + " ms - Resultado: " + resultado;
    }
}

