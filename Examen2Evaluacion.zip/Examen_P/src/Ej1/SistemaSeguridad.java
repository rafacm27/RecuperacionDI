package Ej1;

import java.util.LinkedList;
import java.util.Queue;

public class SistemaSeguridad {
    private String claveCorrecta = "cesur";
    private int consecutiveFailures = 0;
    private long lockExpirationTime = 0;
    private long baseLockDuration = 30000; // 30 segundos
    private int lockMultiplier = 1;
    private Queue<Intento> historial = new LinkedList<>();
    private final int MAX_INTENTOS = 10;

    public void acceder(String clave) throws CuentaBloqueadaException, CredencialesIncorrectasException, DemasiadosIntentosException {
        long tiempoActual = System.currentTimeMillis();

        if (tiempoActual < lockExpirationTime) {
            throw new CuentaBloqueadaException("Cuenta bloqueada. Intente en " + (lockExpirationTime - tiempoActual) / 1000 + " segundos.");
        }

        if (clave.equals(claveCorrecta)) {
            registrarIntento("Éxito");
            consecutiveFailures = 0;
            lockMultiplier = 1;
            System.out.println("Acceso concedido");
        } else {
            consecutiveFailures++;
            registrarIntento("Fallo");

            if (consecutiveFailures >= 3) {
                lockExpirationTime = tiempoActual + (baseLockDuration * lockMultiplier);
                lockMultiplier *= 2;
                consecutiveFailures = 0;
                throw new DemasiadosIntentosException("Demasiados intentos fallidos. Cuenta bloqueada por " + (lockExpirationTime - tiempoActual) / 1000 + " segundos.");
            } else {
                throw new CredencialesIncorrectasException("Contraseña incorrecta. Intento " + consecutiveFailures + " de 3.");
            }
        }
    }

    private void registrarIntento(String resultado) {
        if (historial.size() >= MAX_INTENTOS) {
            historial.poll();
        }
        historial.add(new Intento(resultado));
    }

    public void mostrarHistorial() {
        System.out.println("\nHistorial de intentos:");
        for (Intento intento : historial) {
            System.out.println(intento);
        }
    }
}

