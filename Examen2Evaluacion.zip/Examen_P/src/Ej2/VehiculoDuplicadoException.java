package Ej2;

class VehiculoDuplicadoException extends Exception {
    public VehiculoDuplicadoException(String mensaje) {
        super(mensaje);
    }
}