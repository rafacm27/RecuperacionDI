package Ej2;

class ParkingLlenoException extends Exception {
    public ParkingLlenoException(String mensaje) {
        super(mensaje);
    }
}