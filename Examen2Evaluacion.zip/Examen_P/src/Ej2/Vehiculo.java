package Ej2;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Vehiculo {
    private String matricula;
    private LocalDateTime horaEntrada;

    public Vehiculo(String matricula) {
        this.matricula = matricula;
        this.horaEntrada = LocalDateTime.now();
    }

    public String getMatricula() {
        return matricula;
    }

    public LocalDateTime getHoraEntrada() {
        return horaEntrada;
    }

    @Override
    public String toString() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        return "Matrícula: " + matricula + " | Hora de entrada: " + horaEntrada;
    }
}

