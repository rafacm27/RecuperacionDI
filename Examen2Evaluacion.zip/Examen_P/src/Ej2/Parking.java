package Ej2;

import java.util.ArrayList;

public class Parking {
    private Vehiculo[] vehiculos;
    private final int CAPACIDAD_MAXIMA;

    public Parking(int capacidadMaxima) {
        this.CAPACIDAD_MAXIMA = capacidadMaxima;
        this.vehiculos = new Vehiculo[capacidadMaxima];
    }

    public void ingresarVehiculo(String matricula) throws ParkingLlenoException, VehiculoDuplicadoException {
        if (vehiculos.length >= CAPACIDAD_MAXIMA) {
            throw new ParkingLlenoException("El parking está lleno.");
        }

        for (Vehiculo v : vehiculos) {
            if (v != null && v.getMatricula() == matricula) {
                throw new VehiculoDuplicadoException("El vehículo ya está en el parking.");
            }
        }

        vehiculos[vehiculos.length] = new Vehiculo(matricula);
        System.out.println("Vehículo con matrícula " + matricula + " ingresado correctamente.");
    }

    public void salirVehiculo(String matricula) throws VehiculoNoEncontradoException {
        for (int i = 0; i < vehiculos.length; i++) {
            if (vehiculos[i].getMatricula().equals(matricula)) {
                vehiculos[i] = null;
                System.out.println("Vehículo con matrícula " + matricula + " ha salido del parking.");
                return;
            }
        }
        throw new VehiculoNoEncontradoException("El vehículo no está en el parking.");
    }

    public void mostrarVehiculos() {
        if (vehiculos.length == 0) {
            System.out.println("El parking está vacío.");
        } else {
            System.out.println("Estado actual del parking:");
            for (Vehiculo v : vehiculos) {
                System.out.println(v);
            }
        }
    }
}
