package Ej2;

class VehiculoNoEncontradoException extends Exception {
    public VehiculoNoEncontradoException(String mensaje) {
        super(mensaje);
    }
}
