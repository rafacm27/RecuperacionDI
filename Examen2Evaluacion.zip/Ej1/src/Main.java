class Hebras extends Thread {
    private char caracter;
    private int veces;

    public Hebras(char caracter, int veces) {
        this.caracter = caracter;
        this.veces = veces;
    }

    @Override
    public void run() {
        for (int i = 0; i < veces; i++) {
            System.out.print(caracter);
        }
    }

    public static void main(String[] args) {
        Hebras hebra1 = new Hebras('A', 10);
        Hebras hebra2 = new Hebras('B', 10);
        Hebras hebra3 = new Hebras('C', 10);

        hebra1.start();
        hebra2.start();
        hebra3.start();
    }
}

