package com.ejemplo.variablecompartida;

public class Main {
    public static void main(String[] args) {
        VariableCompartida varComp = new VariableCompartida();
        Hebra h1 = new Hebra(varComp);
        Hebra h2 = new Hebra(varComp);

        h1.start();
        h2.start();

        try {
            h1.join();
            h2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Valor final de v: " + varComp.get());
    }
}
