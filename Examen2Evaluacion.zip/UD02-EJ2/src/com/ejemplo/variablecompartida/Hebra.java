package com.ejemplo.variablecompartida;

public class Hebra extends Thread {
    private VariableCompartida varComp;

    public Hebra(VariableCompartida varComp) {
        this.varComp = varComp;
    }

    @Override
    public void run() {
        for (int i = 0; i < 10; i++) {
            varComp.inc();
        }
    }
}
