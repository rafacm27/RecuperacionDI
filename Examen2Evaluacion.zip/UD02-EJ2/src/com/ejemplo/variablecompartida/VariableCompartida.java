package com.ejemplo.variablecompartida;

public class VariableCompartida {
    private int v;

    public synchronized void set(int v) {
        this.v = v;
    }

    public synchronized int get() {
        return v;
    }

    public synchronized void inc() {
        v++;
    }
}
