public class FibonacciThread extends Thread {
    private int index;
    private long[] results;

    public FibonacciThread(int index, long[] results) {
        this.index = index;
        this.results = results;
    }

    @Override
    public void run() {
        if (index == 0) {
            results[0] = 0;
        } else if (index == 1) {
            results[1] = 1;
        } else {
            while (results[index - 1] == -1 || results[index - 2] == -1) {
                // Espera activa
                try {
                    Thread.sleep(1); // Añadimos un pequeño sleep para evitar consumo excesivo de CPU
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            results[index] = results[index - 1] + results[index - 2];
        }
    }

    public static void main(String[] args) {
        int N = 10; // Cambia este valor para calcular más términos
        long[] results = new long[N + 1]; // Ajustamos el tamaño del array para incluir el término N
        for (int i = 0; i <= N; i++) {
            results[i] = -1; // Inicializa los resultados con -1
        }

        FibonacciThread[] threads = new FibonacciThread[N + 1]; // Ajustamos el tamaño del array de hebras
        for (int i = 0; i <= N; i++) {
            threads[i] = new FibonacciThread(i, results);
            threads[i].start();
        }

        for (int i = 0; i <= N; i++) {
            try {
                threads[i].join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        for (int i = 0; i <= N; i++) {
            System.out.println("Fibonacci(" + i + ") = " + results[i]);
        }
    }
}
