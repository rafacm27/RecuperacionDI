// Ejemplo práctico: Encuesta de satisfacción
public class SurveyAnalysis {
    public static void main(String[] args) {
        // 1. Crear e inicializar un array con las respuestas de la encuesta (valores de 1 a 5)
        int[] respuestas = {4, 5, 3, 4, 2, 5, 1, 3, 4, 5, 3, 2, 4, 5, 1};

        // 2. Mostrar todas las respuestas
        System.out.println("Respuestas de la encuesta:");
        for (int i = 0; i < respuestas.length; i++) {
            System.out.println("Participante " + (i + 1) + ": " + respuestas[i]);
        }

        // 3. Calcular la media de las respuestas
        int suma = 0;
        for (int respuesta : respuestas) {
            suma += respuesta;
        }
        double media = (double) suma / respuestas.length;
        System.out.printf("\nMedia de satisfacción: %.2f\n", media);

        // 4. Contar cuántas respuestas corresponden a cada puntuación
        int[] conteo = new int[5]; // Array para almacenar el conteo de 1 a 5
        for (int respuesta : respuestas) {
            conteo[respuesta - 1]++;
        }

        System.out.println("\nDistribución de respuestas:");
        for (int i = 0; i < conteo.length; i++) {
            System.out.println("Puntuación " + (i + 1) + ": " + conteo[i] + " respuestas");
        }

        // 5. Encontrar la puntuación más común
        int maxConteo = conteo[0];
        int puntuacionComun = 1;
        for (int i = 1; i < conteo.length; i++) {
            if (conteo[i] > maxConteo) {
                maxConteo = conteo[i];
                puntuacionComun = i + 1;
            }
        }
        System.out.println("\nPuntuación más común: " + puntuacionComun + " (" + maxConteo + " respuestas)");
    }
}
