package com.tienda.service;

import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.springframework.stereotype.Service;
import java.io.File;
import java.util.HashMap;
import java.util.List;

@Service
public class ReporteService {
    public String exportReport(List<?> data, String reportPath) throws JRException {
        File file = new File(reportPath);
        JasperReport jasperReport = JasperCompileManager.compileReport(file.getAbsolutePath());
        JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(data);
        JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, new HashMap<>(), dataSource);
        JasperExportManager.exportReportToPdfFile(jasperPrint, "reporte.pdf");
        return "Reporte generado con éxito!";
    }
}
