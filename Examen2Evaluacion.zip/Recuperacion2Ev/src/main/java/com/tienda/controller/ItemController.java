package com.tienda.controller;

import com.tienda.model.Item;
import com.tienda.service.ItemService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/items")
public class ItemController {

    private final ItemService itemService;

    public ItemController(ItemService itemService) {
        this.itemService = itemService;
    }

    @GetMapping
    public List<Item> listarItems() {
        return itemService.obtenerTodosLosItems();
    }

    @GetMapping("/{id}")
    public Item obtenerItem(@PathVariable String id) {
        return itemService.obtenerItemPorId(id);
    }

    @PostMapping
    public Item agregarItem(@RequestBody Item item) {
        return itemService.guardarItem(item);
    }

    @DeleteMapping("/{id}")
    public void eliminarItem(@PathVariable String id) {
        itemService.eliminarItem(id);
    }
}

