package com.tienda.service;

import com.tienda.model.Item;
import com.tienda.repository.ItemRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class ItemService {

    private final ItemRepository itemRepository;

    public ItemService(ItemRepository itemRepository) {
        this.itemRepository = itemRepository;
    }

    public List<Item> obtenerTodosLosItems() {
        return itemRepository.findAll();
    }

    public Item obtenerItemPorId(String id) {
        return itemRepository.findById(id).orElse(null);
    }

    public Item guardarItem(Item item) {
        return itemRepository.save(item);
    }

    public void eliminarItem(String id) {
        itemRepository.deleteById(id);
    }
}
