package com.tienda.tienda;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Recuperacion2EvApplication {

    public static void main(String[] args) {
        SpringApplication.run(Recuperacion2EvApplication.class, args);
    }

}
