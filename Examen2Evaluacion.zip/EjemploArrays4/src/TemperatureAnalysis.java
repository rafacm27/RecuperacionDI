// Ejemplo práctico: Registro y análisis de temperaturas
public class TemperatureAnalysis {
    public static void main(String[] args) {
        // 1. Crear e inicializar un array de temperaturas de una semana
        double[] temperaturas = {21.5, 23.0, 19.8, 22.4, 20.6, 18.9, 24.3};

        // 2. Mostrar las temperaturas registradas
        System.out.println("Temperaturas registradas durante la semana:");
        for (int i = 0; i < temperaturas.length; i++) {
            System.out.println("Día " + (i + 1) + ": " + temperaturas[i] + "°C");
        }

        // 3. Calcular la temperatura promedio
        double suma = 0;
        for (double temp : temperaturas) {
            suma += temp;
        }
        double promedio = suma / temperaturas.length;
        System.out.printf("\nTemperatura promedio: %.2f°C\n", promedio);

        // 4. Encontrar la temperatura más alta y más baja
        double maxTemp = temperaturas[0];
        double minTemp = temperaturas[0];
        int diaMax = 1;
        int diaMin = 1;
        for (int i = 1; i < temperaturas.length; i++) {
            if (temperaturas[i] > maxTemp) {
                maxTemp = temperaturas[i];
                diaMax = i + 1;
            }
            if (temperaturas[i] < minTemp) {
                minTemp = temperaturas[i];
                diaMin = i + 1;
            }
        }
        System.out.println("Temperatura más alta: " + maxTemp + "°C (Día " + diaMax + ")");
        System.out.println("Temperatura más baja: " + minTemp + "°C (Día " + diaMin + ")");

        // 5. Contar cuántos días tuvieron temperaturas por encima del promedio
        int diasSobrePromedio = 0;
        for (double temp : temperaturas) {
            if (temp > promedio) {
                diasSobrePromedio++;
            }
        }
        System.out.println("\nNúmero de días con temperaturas por encima del promedio: " + diasSobrePromedio);
    }
}
